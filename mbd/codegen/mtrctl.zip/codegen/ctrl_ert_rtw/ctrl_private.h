/*
 * ctrl_private.h
 *
 * Code generation for model "ctrl".
 *
 * Model version              : 1.904
 * Simulink Coder version : 8.14 (R2018a) 06-Feb-2018
 *
 */

#ifndef RTW_HEADER_ctrl_private_h_
#define RTW_HEADER_ctrl_private_h_
#include "rtwtypes.h"
#endif                                 /* RTW_HEADER_ctrl_private_h_ */
